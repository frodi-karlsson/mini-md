<nav-component templates="editing,head,home->index,socials,titles"></nav-component>
