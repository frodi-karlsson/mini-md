/**
 * A custom tag that wraps a page of markdown content
 */
class MiniMarkdownBuilder extends HTMLElement {
  static n = 0;

  connectedCallback() {
    const title = this.getAttribute("title");
    const lang = this.getAttribute("lang");
    const scheme = this.getAttribute("scheme");
    const charset = this.getAttribute("charset");
    const description = this.getAttribute("description");
    const author = this.getAttribute("author");
    const keywords = this.getAttribute("keywords");
    const viewport = this.getAttribute("viewport");
    const robots = this.getAttribute("robots");
    const ogTitle = this.getAttribute("og:title");
    const ogType = this.getAttribute("og:type");
    const ogUrl = this.getAttribute("og:url");
    const ogDescription = this.getAttribute("og:description");
    const ogImage = this.getAttribute("og:image");
    const twitterCard = this.getAttribute("twitter:card");
    const ogLocale = this.getAttribute("og:locale");
    const ogSiteName = this.getAttribute("og:site_name");
    const twitterImageAlt = this.getAttribute("twitter:image:alt");

    const head =
      `
        <title>${title ?? "Default title"}</title>` +
      `<meta charset="${charset ?? "utf-8"}">` +
      (viewport ? `<meta name="viewport" content="${viewport}">` : "") +
      (description
        ? `<meta name="description" content="${description}">`
        : "") +
      (author ? `<meta name="author" content="${author}">` : "") +
      (keywords ? `<meta name="keywords" content="${keywords}">` : "") +
      (robots ? `<meta name="robots" content="${robots}">` : "") +
      (ogTitle ? `<meta property="og:title" content="${ogTitle}">` : "") +
      (ogType ? `<meta property="og:type" content="${ogType}">` : "") +
      (ogUrl ? `<meta property="og:url" content="${ogUrl}">` : "") +
      (ogDescription
        ? `<meta property="og:description" content="${ogDescription}">`
        : "") +
      (ogImage ? `<meta property="og:image" content="${ogImage}">` : "") +
      (twitterCard
        ? `<meta name="twitter:card" content="${twitterCard}">`
        : "") +
      (ogLocale ? `<meta property="og:locale" content="${ogLocale}">` : "") +
      (ogSiteName
        ? `<meta property="og:site_name" content="${ogSiteName}">`
        : "") +
      (twitterImageAlt
        ? `<meta name="twitter:image:alt" content="${twitterImageAlt}">`
        : "") +
      `<link rel="stylesheet" href="styles/styles.css">` +
      (scheme
        ? `<link rel="stylesheet" href="styles/schemes/${scheme}.css">`
        : "");
    const content = `
        <main lang="${lang ?? "en"}">
          <div class="mini-md">
            <slot></slot>
          </div>
        </main>
      `;
    const html = `
        ${content}
      `;
    const template = document.createElement("template");
    template.innerHTML = html;
    document.head.innerHTML = head;
    this.appendChild(template.content.cloneNode(true));
  }

  /**
   * Builds the component
   * @param {Window} window The window to build the component in
   * @returns {HTMLElement}
   */
  static buildComponent(window) {
    window.customElements.define("mini-md", MiniMarkdownBuilder);
  }
}
MiniMarkdownBuilder.buildComponent(window);
